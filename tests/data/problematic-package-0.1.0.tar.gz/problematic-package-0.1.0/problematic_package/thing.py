def do_stuff():
    return True
