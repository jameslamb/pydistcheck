try:
    from spongebobcase import tospongebob
except ImportError:
    def tospongebob(x):
        return("install 'spongebobcase' to use this")
SPONGEBOB_STR = tospongebob("but does it scale?")
