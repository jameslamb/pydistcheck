from spongebobcase import tospongebob
SPONGEBOB_STR = tospongebob("but does it scale?")
