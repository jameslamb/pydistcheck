print('Python is great.')
